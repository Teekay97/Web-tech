﻿<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "online");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
  	
    $image_ct = $_POST['image_ct'];
    $image_tp = $_POST['image_tp'];
    $image_price = $_POST['image_price'];
    $product_name = $_POST['product_name'];


  	// image file directory
  	$target = "pics/".basename($image);

  	$sql = "INSERT INTO products (name, catagory, type, product_img, price) VALUES ('$product_name','$image_ct','$image_tp','$image', '$image_price')";
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM products");
?>
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>
<style type="text/css">
   #content{
   	width: 50%;
   	margin: 20px auto;
   	border: 1px solid #cbcbcb;
   }
   form{
   	width: 50%;
   	margin: 20px auto;
   }
   form div{
   	margin-top: 5px;
   }
   #img_div{
   	width: 80%;
   	padding: 5px;
   	margin: 15px auto;
   	border: 1px solid #cbcbcb;
   }
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
   img{
   	float: left;
   	margin: 5px;
   	width: 300px;
   	height: 140px;
   }
</style>
</head>
<body>
<div id="content">
  <?php
    while ($row = mysqli_fetch_array($result)) {
      echo "<div id='img_div'>";
      	echo "<img src='pics/".$row['image']."' >";
      	echo "<p>".$row['image']."</p>";
      echo "</div>";
    }
  ?>
  <form method="POST" action="upload.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div>
  	  <input type="file" name="image">
  	</div>
  	<div>

 <textarea 
      	id="text"       	
      	name="image_ct" 
      	placeholder="Catergory"></textarea>

 <textarea 
      	id="text"       	
      	name="image_tp" 
      	placeholder="Type"></textarea>
  	</div>

<textarea 
      	id="text"       	
      	name="product_name" 
      	placeholder="Product Name"></textarea>
  	</div>

<div>
  	  <input type="number" name="image_price" step="any">
  	</div>

  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
  </form>
</div>
</body>
</html>