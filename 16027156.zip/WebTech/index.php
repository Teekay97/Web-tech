﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" href=".png" />
    <title>Teekay's</title>
    <script type=text/javascript src='bootstrap/js/bootstrap.js'></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap-responsive.css" />
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="main.css" />
</head>
<body>
    <header>
        Teekay's Grocers
    </header>

    
        <a class="brand" href="index.php" title="Home"><img src="teekay1.png" title="Home" /></a>

    <div class="navbar">
        <ul class="nav">
            <!--   -->
            <li title="Fruit, Veg, Dairy, Meat and Fish"><a href="fresh/fresh.php">Fresh Produce</a></li>
            <li title="Baked produce"><a href="bakery/bakery.php">Bakery</a></li>
            <li title="Meat, fish and veg"><a href="frozen/frozen.php">Frozen food</a></li>
            <li title="Food cupboard"><a href="cupboard/cupboard.php">Cupboard</a></li>
            <li title="Thirsty? Click here!"><a href="drinks/drinks.php">Drinks</a></li>
            <li title="Cleaning and hygeine"><a href="household/household.php">Household</a></li>
            <li title="Baby stuff"><a href="baby/baby.php">Baby and toddler</a></li>
            <li title="Electricals and Leisure"><a href="houseware/houseware.php">Houseware and Garden</a></li>
        </ul>
    </div>
    <br>
	<iframe width="80%" height="500" 
                        src="https://www.youtube.com/embed/vpIV214yaj4?rel=0" 
                        frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> 

    <h1> Welcome </h1>

</body>
</html>