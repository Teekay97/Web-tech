﻿<?php
session_start();
include_once("../config.php");


//current URL of the Page. cart_update.php redirects back to this URL
$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
     <meta name name="description" content="Simply the best"/>
     <meta name="keywords" content="Simply the best, grocers, shoping, food ordering, hungry, Tank, Zimbabwe"/>
    <link rel="icon" href="../teekayg.png" />
    <title>Teekay's</title>
	
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="../main.css" />
	<link rel="stylesheet" type="text/css" href="../css/content.css">
    <link rel="stylesheet" type="text/css" href="../css/sidebar.css">
	<link rel="stylesheet" type="text/css" href="../css/navbar.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>

</head>
<body>
    <header>
        Teekay's Grocers
    </header>

    <a class="brand" href="../index.php" title="Home"><img src="../teekay1.png" title="Home" /></a>

    <div class="navbar">
        <ul class="nav">
            <!--   -->
            <li title="Fruit, Veg, Dairy, Meat and Fish"><a href="../fresh/fresh.php">Fresh Produce</a></li>
            <li title="Baked produce"><a href="../bakery/bakery.php">Bakery</a></li>
            <li title="Meat, fish and veg"><a href="../frozen/frozen.php">Frozen food</a></li>
            <li class="active" title="Food cupboard"><a href="../cupboard/cupboard.php">Cupboard</a></li>
            <li title="Thirsty? Click here!"><a href="../drinks/drinks.php">Drinks</a></li>
            <li title="Cleaning and hygeine"><a href="../household/household.php">Household</a></li>
            <li title="Baby stuff"><a href="../baby/baby.php">Baby and toddler</a></li>
            <li title="Electricals and Leisure"><a href="../houseware/houseware.php">Houseware and Garden</a></li>
<li title="shoping cart"><a href="../cart.php">cart</a></li>
        </ul>
    </div>
    <div class="wrapper">
        <nav id="sidebar">
            <ul class="list-unstyled components">
                <li title="Snacks" style="border-top-right-radius: 10px"><a href="cupboard.php">Snacks</a></li>
                <li title="Cereal"><a href="cereal.php">Cereal</a></li>
                <li title="Spreads"><a href="spreads.php">Spreads</a></li>
                <li title="Baking products"><a href="baking.php">Home baking</a></li>
                <li class="active" title="Pasta and rice"><a href="pasta.php">Rice and pasta</a></li>
                <li title="Canned or packaged products"><a href="can.php">Canned and packaged</a></li>
                <li title="Sauces, spices and dresses"><a href="sauce.php">Sauces, spices and dresses</a></li>
            </ul>
        </nav>
    </div>



<!----><!-- Products List Start CONTENT -->
<div class="content">
	<section class="container">

<div class="row" id="clothing">
<?php
$results = $mysqli->query("SELECT name, catagory, type, product_img, price FROM products WHERE catagory='cupboard' AND type='pasta' ORDER BY id ASC");
if($results){ 
$products_item = '<ul style="list-style-type: none;">';
//fetch results set as object and output HTML

while($obj = $results->fetch_object())
{
$products_item .= <<<EOT
	
	<div class="col-sm-4">
	<div class="box">
	<li class="product">
	<form method="post" action="../cart_update.php">	
	<img src="../pics/fresh/{$obj->product_img}">
	<p align="center">{$obj->name}</p>
	<p align="center" style="font-size: 1.2em;">{$currency}{$obj->price} </p>
	
	
	<input type="hidden" name="name" value="{$obj->name}" />
	
	<input type="hidden" name="type" value="add" />
	<input type="hidden" name="return_url" value="{$current_url}" />

	<div align="center">
		<label>Quantity: </label>
		<input type="text" size="2" maxlength="2" name="product_qty" value="1"/>&nbsp;&nbsp;
		<button type="submit" class="add_to_cart" id="myButton">Add to Cart</button>
	</div>
	
	</form>
	</li>
	</div>
	</div>
	
EOT;
}
$products_item .= '</ul>';
echo $products_item;
}
?>    
</div>
</section>
</div>



</body>
</html>